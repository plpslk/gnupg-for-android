#!/system/bin/sh

. /data/data/info.guardianproject.gpg/app_opt/aliases/common

/data/data/info.guardianproject.gpg/app_opt/bin/gpgsm-gencert.sh $@
