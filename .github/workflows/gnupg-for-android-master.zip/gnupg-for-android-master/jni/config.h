
#define VERSION "pinentry Activity for Android v0.0.0"
